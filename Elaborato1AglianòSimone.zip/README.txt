ESECUZIONE PARSER
1.Su Netbeans importare il Maven ProjecT
2. Effettuare Clean and Build with Dependencies
3. A questo punto basta effettuare run e se non ci sono eccezioni alla fine dell'esecuzione nel file symboltable.txt (presente nella directory del progetto) si vedr� l'elenco degli identificatori.

ULTERIORI TENTATIVI
Andare nel file source.txt (presente nella directory del progetto) e modificare il codice che andr� in ingresso al parser.
Oppure utilizzare il file source1.txt, gi� presente, dove si utilizza la variabile j senza averla dichiarata. Quindi modificare il nome del file nel main ed eseguire.
Comparir� l'eccezione.
Utilizzare il file sourc2.txt dove viene dichiarata due volte una variabile, apparir� su console un'eccezione.